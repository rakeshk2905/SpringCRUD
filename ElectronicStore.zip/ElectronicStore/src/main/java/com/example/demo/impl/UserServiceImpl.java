package com.example.demo.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.dto.PageableResponse;
import com.example.demo.dto.UserDto;
import com.example.demo.entites.Users;
import com.example.demo.exceptionas.ResourceNotFoundException;
import com.example.demo.helper.Helper;
import com.example.demo.repositores.UserRepository;
import com.example.demo.services.UserService;


/* Author
 * pravin sable
 */
@Service
public class UserServiceImpl implements UserService {
    enum  UserImage{
    	
    	userimage_not_found_in_folder
    	
    }
    	
	private  UserRepository userRepository;
	@Value(value = "@{user.profile.image.path}")
	private String ImagePath;
	
	private Logger logger=LoggerFactory.getLogger(UserServiceImpl.class);
	
	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository=userRepository;
	}
	
	@Override
	public UserDto createUser(UserDto userDto) {
	    String userId=	UUID.randomUUID().toString();
	    userDto.setUserId(userId);
		Users users =dtoToEntity(userDto);
		Users savedUser =userRepository.save(users);
		
		UserDto newDto= entityToDto(savedUser);
		return newDto;
	}

	
	@Override
	public UserDto updateUser(UserDto userDto, String userId) {
		Users users= userRepository.findById(userId).orElseThrow(()->new RuntimeException("User not found with given id !!"));
		users.setName(userDto.getName());
		users.setAbout(userDto.getAbout());
		users.setPassword(userDto.getPassword());
		users.setGender(userDto.getGender());
		users.setImageName(userDto.getImageName());
		Users updateUser =userRepository.save(users);
		UserDto updateDto =entityToDto(updateUser);
		return updateDto;
	}

	@Override
	public void deleteUser(String userId) {
	Users users =userRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("User not found with given id !!"));
	userRepository.delete(users);

	
	// delete user profile image
	String fullPath= ImagePath+users.getImageName();
	try {
	Path path =Paths.get(fullPath);
	Files.delete(path);
	
	}catch(NoSuchFileException e) {
		e.printStackTrace();
		logger.info(":"+UserImage.userimage_not_found_in_folder);
	}catch(IOException ex) {
		ex.printStackTrace();
	}
	
	}

	@Override
	public PageableResponse<UserDto> getAllUser(int pageNumber,int pageSize,String sortBy, String sortDir) {
	Sort sort =(sortDir.equalsIgnoreCase("desc"))?Sort.by(sortBy).descending():(Sort.by(sortBy).ascending());
	Pageable pageable=PageRequest.of(pageNumber, pageSize,sort);
	Page<Users>page =userRepository.findAll(pageable);
	PageableResponse<UserDto> response =Helper.getPageableResponse(page, UserDto.class);
	return response;
	}

	@Override
	public UserDto getuserByEmail(String email) {
	Users users =userRepository.findByEmail(email).orElseThrow(()->new ResourceNotFoundException("User not found with this email !!"));
		return entityToDto(users);
	}

	@Override
	public UserDto getUserById(String userId) {
	Users users = userRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("No such user found!!"));
	return entityToDto(users);
	}

	@Override
	public List<UserDto> searchUser(String keyword) {
	List<Users>users =userRepository.findByNameContaining(keyword);
	List<UserDto>dtoList= users.stream().map(user->entityToDto(user)).collect(Collectors.toList());
	return dtoList;
	}
	private UserDto entityToDto(Users savedUser) {
	UserDto userDto=	UserDto.builder()
		.userId(savedUser.getUserId())
		.name(savedUser.getName())
		.email(savedUser.getEmail())
		.about(savedUser.getAbout())
		.password(savedUser.getPassword())
		.imageName(savedUser.getImageName())
		.gender(savedUser.getGender()).build();		
		return userDto;
	}
	private Users dtoToEntity(UserDto userDto) {
		Users users=Users.builder()
		.userId(userDto.getUserId())
		.name(userDto.getName())
		.email(userDto.getEmail())
		.about(userDto.getAbout())
		.password(userDto.getPassword())
		.gender(userDto.getGender())
		.imageName(userDto.getImageName())
		.build();
		return users;
		}

}
