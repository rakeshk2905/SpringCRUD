package com.example.demo.repositores;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entites.Users;
/*
 * author
 * pravin sable
 */
public interface UserRepository extends JpaRepository<Users, String>{
  Optional<Users> findByEmail(String email);
  Optional<Users> findByEmailAndPassword(String email,String password);
  List<Users> findByNameContaining(String name);
}
