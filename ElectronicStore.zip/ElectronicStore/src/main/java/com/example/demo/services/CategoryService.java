package com.example.demo.services;

import com.example.demo.dto.CategoryDto;
import com.example.demo.dto.PageableResponse;
/*
 * author
 * pravin sable
 */
public interface CategoryService {
CategoryDto create(CategoryDto categoryDto);

CategoryDto update(CategoryDto categoryDto,String categoryId);

void delete(String categoryId);

PageableResponse<CategoryDto>getAll(int pageNumber,int pageSize,String sortBy,String sortDir);

CategoryDto get(String categoryId);
}
