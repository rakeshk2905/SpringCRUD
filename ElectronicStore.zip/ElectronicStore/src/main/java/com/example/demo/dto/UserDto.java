package com.example.demo.dto;

import com.example.demo.validations.ValidImage;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/*
 * author
 * pravin sable
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class UserDto {

	private String userId;
	@NotBlank(message = "Password is required")
	private String password;
	@Pattern(regexp = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$",message = "Invalid email")
	@NotBlank(message = "Email is required")
	private String email;
	
	@Size(max = 25,message = "Invalid Name")
	private String name;

	private String gender;
    @NotBlank
	private String about;
	
    @ValidImage
	private String imageName;
}
