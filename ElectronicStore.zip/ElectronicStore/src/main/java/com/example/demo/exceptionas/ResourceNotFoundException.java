package com.example.demo.exceptionas;

import lombok.Builder;
import lombok.NoArgsConstructor;
/*
 * author
 * pravin sable
 */
@Builder
@NoArgsConstructor
public class ResourceNotFoundException extends RuntimeException {
 
 
 public ResourceNotFoundException(String message) {
	 super(message);
 }
}

