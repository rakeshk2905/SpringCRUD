package com.example.demo.services;

import java.util.List;

import com.example.demo.dto.PageableResponse;
import com.example.demo.dto.ProductDto;
/*
 * author
 * pravin sable
 */
public interface productService {
    //create
	ProductDto create(ProductDto productDto);
	
	//update
	ProductDto update(ProductDto productDto,String productId);
	
	//delete
	void delete(String productId);
	
	//get single
	ProductDto get(String productId);
	
	//get all
	 PageableResponse<ProductDto>getAll(int pageNumber,int pageSize,String sortBy,String sortDir);
	
	//get all:Live
	 PageableResponse<ProductDto>getAllLive(int pageNumber,int pageSize,String sortBy,String sortDir);
	
	//search product
	 PageableResponse<ProductDto> searchByTitle(String subTitle,int pageNumber,int pageSize,String sortBy,String sortDir);
}
