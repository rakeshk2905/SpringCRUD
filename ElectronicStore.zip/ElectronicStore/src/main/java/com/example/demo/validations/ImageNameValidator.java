package com.example.demo.validations;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
/*
 * author
 * pravin sable
 */
public class ImageNameValidator implements ConstraintValidator<ValidImage, String> {

	private Logger logger=LoggerFactory.getLogger(ImageNameValidator.class);
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		logger.info("Message from isValid:{} ",value);
		//Logic
		if(value.isBlank()) {
			return false; 
		}else {
			return true;
		}
		
	}

}
