package com.example.demo.repositores;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entites.Product;
/*
 * author
 * pravin sable
 */
public interface ProductRepository extends JpaRepository<Product,String> {
Page<Product>findTitleContaning(String subTitle,Pageable pageable);
List<Product>findByLive(boolean live);
Page<Product>findByLiveTrue(Pageable pageable);
}
