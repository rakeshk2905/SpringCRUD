package com.example.demo.impl;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.dto.CategoryDto;
import com.example.demo.dto.PageableResponse;
import com.example.demo.entites.Category;
import com.example.demo.exceptionas.ResourceNotFoundException;
import com.example.demo.helper.Helper;
import com.example.demo.repositores.CategoryRepository;
import com.example.demo.services.CategoryService;
/*
 * author
 * pravin sable
 */
@Service
public class CategoryServiceImpl implements CategoryService{
	private ModelMapper modelMapper;
	private CategoryService categoryService;
	private CategoryRepository categoryRepository;
	public CategoryServiceImpl(CategoryService categoryService,ModelMapper modelMapper,CategoryRepository
			categoryRepository) {
		this.categoryService =categoryService;
		this.modelMapper=modelMapper;
        this.categoryRepository=categoryRepository;		
	}

	@Override
	public CategoryDto create(CategoryDto categoryDto) {
		// TODO Auto-generated method stub
		
		Category category=modelMapper.map(categoryDto, Category.class);
		Category savedCategory=categoryRepository.save(category);
		return modelMapper.map(savedCategory,CategoryDto.class);
	}

	@Override
	public CategoryDto update(CategoryDto categoryDto, String categoryId) {
		// TODO Auto-generated method stub
		// get Category of given id
		Category category = categoryRepository.findById(categoryId).orElseThrow(()->new ResourceNotFoundException("Category Not found with given ID!!"));
		
		//update Category details
		category.setTitle(categoryDto.getTitle());
		category.setDescription(categoryDto.getDescription());
		category.setCoverImage(categoryDto.getCoverImage());
		//category.setCategoryId(categoryDto.getCategoryId());
		Category updatedCategory= categoryRepository.save(category);
		return modelMapper.map(updatedCategory,CategoryDto.class);
	}

	@Override
	public void delete(String categoryId) {
		// TODO Auto-generated method stub
		Category category =categoryRepository.findById(categoryId).orElseThrow(()->new RuntimeException("Category Not found with given ID!!"));
		categoryRepository.delete(category);
		
	}

	@Override
	public PageableResponse<CategoryDto> getAll(int pageNumber,int pageSize,String sortBy,String sortDir) {
		// TODO Auto-generated method stub
		Sort sort=(sortDir.equalsIgnoreCase("desc")?(Sort.by(sortBy).descending()):Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		Page<Category> page = categoryRepository.findAll(pageable);
		
	    PageableResponse<CategoryDto>pageableResponse=	Helper.getPageableResponse(page, CategoryDto.class);
		return pageableResponse;
	}

	@Override
	public CategoryDto get(String categoryId) {
		
		return null;
	}

}
