package com.example.demo.entites;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/*
 * author
 * pravin sable
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="catergories")

public class Category {
@Id
@Column(name="id")
private String categoryId;
@Column(name="category_title")
private String title;
@Column(name="category_desc")
private String description;
private String coverImage;

}
