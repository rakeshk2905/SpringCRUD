package com.example.demo.entites;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="products")
/*
 * author
 * pravin sable
 */
public class Product {

	@Id
	private String productId;
	
	private String title;
	
	@Column(length = 1000)
	private String description;
	
	private double price;
	
	private int quantity;
	
	private Date addedDate;
	
	private boolean live;
	
	private boolean stock;
	
	private double discountedPrice;
	private String productImageName;
	
	
	
}
