package com.example.demo.impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.example.demo.dto.PageableResponse;
import com.example.demo.dto.ProductDto;
import com.example.demo.entites.Product;
import com.example.demo.helper.Helper;
import com.example.demo.repositores.ProductRepository;
import com.example.demo.services.productService;
/*
 * author
 * pravin sable
 */
public class ProductServiceImpl implements productService{

	private ModelMapper mapper;
	private ProductRepository productRepository;
	
	public ProductServiceImpl(ModelMapper mapper,ProductRepository productRepository) {
		this.mapper=mapper;
		this.productRepository=productRepository;
	}
	@Override
	public ProductDto create(ProductDto productDto) {
		Product product = mapper.map(productDto, Product.class);
		Product savedProduct =productRepository.save(product);
		return mapper.map(savedProduct, ProductDto.class);
	}

	@Override
	public ProductDto update(ProductDto productDto, String productId) {
		Product product = productRepository.findById(productId).orElseThrow(()-> new RuntimeException("product not found with given ID!!"));
		product.setTitle(productDto.getTitle());
		product.setPrice(productDto.getPrice());
		product.setAddedDate(productDto.getAddedDate());
		product.setDescription(productDto.getDescription());
		product.setQuantity(productDto.getQuantity());
		product.setLive(productDto.isLive());
        product.setStock(productDto.isStock());
        product.setDiscountedPrice(productDto.getDiscountedPrice());
        
        Product updatedProduct = productRepository.save(product);
		return mapper.map(updatedProduct, ProductDto.class);
	}

	@Override
	public void delete(String productId) {
    Product product = productRepository.findById(productId).orElseThrow(()-> new RuntimeException("product not found with given ID!!"));
    productRepository.delete(product);	
	}

	@Override
	public ProductDto get(String productId) {
		
		return null;
	}

	@Override
	public PageableResponse<ProductDto> getAll(int pageNumber,int pageSize,String sortBy,String sortDir) {
     
		Sort sort=(sortDir.equalsIgnoreCase("desc"))?(Sort.by(sortBy).descending()):(Sort.by(sortBy).ascending());
		Pageable pageable =PageRequest.of(pageNumber, pageSize,sort);
		Page<Product>page =productRepository.findByLiveTrue(pageable);
		return Helper.getPageableResponse(page, ProductDto.class);
	}

	@Override
	public  PageableResponse<ProductDto> getAllLive(int pageNumber,int pageSize,String sortBy,String sortDir) {
		
		Sort sort=(sortDir.equalsIgnoreCase("desc"))?(Sort.by(sortBy).descending()):(Sort.by(sortBy).ascending());
		Pageable pageable =PageRequest.of(pageNumber, pageSize,sort);
		Page<Product>page =productRepository.findByLiveTrue(pageable);
		return Helper.getPageableResponse(page, ProductDto.class);
	}

	@Override
	public  PageableResponse<ProductDto> searchByTitle(String subTitle,int pageNumber,int pageSize,String sortBy,String sortDir) {
		
		Sort sort=(sortDir.equalsIgnoreCase("desc"))?(Sort.by(sortBy).descending()):(Sort.by(sortBy).ascending());
		Pageable pageable =PageRequest.of(pageNumber, pageSize,sort);
		Page<Product>page =productRepository.findTitleContaning(subTitle, pageable);
		return Helper.getPageableResponse(page, ProductDto.class);
	}

}
