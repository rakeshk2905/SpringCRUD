package com.example.demo.entites;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name="users")
/*
 * author
 * pravin sable
 */
public class Users {

	@Id
	private String userId;
	@Column(name="password",length =10)
	private String password;
	@Column(name="email",unique=true)
	private String email;
	@Column(name="name")
	private String name;
	@Column(name="gender")
	private String gender;
	@Column(name="about",length=1000)
	private String about;
	@Column(name="user_image_name")
	private String imageName;
	
	
}
