package com.example.demo.services;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.web.multipart.MultipartFile;
/*
 * author
 * pravin sable
 */
public interface FileService {

	 String uploadFile(MultipartFile file,String path) throws IOException;
	 
	 InputStream getResource(String path,String name);
	 
	 
}

