package com.example.demo.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/*
 * author
 * pravin sable
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CategoryDto {
	
	private String categoryId;
	@NotBlank
	@Size(min = 4)
	
	private String title;
	@NotBlank(message = "Description required!!")
	private String description;
	@NotBlank
	private String coverImage;

}
