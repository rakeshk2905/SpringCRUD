package com.example.demo.exceptionas;
/*
 * author
 * pravin sable
 */
public class BadAPIRequest extends RuntimeException {

	public BadAPIRequest(String message) {
		super(message);
	}
	
	public BadAPIRequest() {
	super("Bad Request !!");
	}
}

