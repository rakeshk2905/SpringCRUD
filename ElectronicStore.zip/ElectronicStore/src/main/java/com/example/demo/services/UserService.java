package com.example.demo.services;

import java.util.List;

import com.example.demo.dto.PageableResponse;
import com.example.demo.dto.UserDto;
/*
 * author
 * pravin sable
 */
public interface UserService {

	
	//create
	UserDto createUser(UserDto userDto);
	//update
	UserDto updateUser(UserDto userDto,String userId);
	//delete
	void deleteUser(String userId);
	//getAll user
	PageableResponse<UserDto>getAllUser(int pageNumber,int pageSize,String sortBy,String sortDir);
	//get singale user byEmail
	UserDto getuserByEmail(String email);
	// get singale user  by id
	UserDto getUserById(String userId);
   // search user
	List<UserDto>searchUser(String keyword);
	
	
}
