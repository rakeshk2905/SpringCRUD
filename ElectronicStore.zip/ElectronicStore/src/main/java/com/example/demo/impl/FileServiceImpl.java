package com.example.demo.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.exceptionas.BadAPIRequest;
import com.example.demo.services.FileService;
/*
 * author
 * pravin sable
 */
@Service
public class FileServiceImpl implements FileService {
	
	Logger logger = LoggerFactory.getLogger(FileServiceImpl.class);
	@Override
	public String uploadFile(MultipartFile file, String path) throws IOException{
		String orignalFilename= file.getOriginalFilename();
		logger.info("Filename : {} "+orignalFilename);
		String filename=UUID.randomUUID().toString();
		String extention = orignalFilename.substring(orignalFilename.lastIndexOf("."));
		String fileNameWithExtention =filename+extention;
		String fullPathWithFileName=path+fileNameWithExtention;
		
		
		logger.info("Full image path: {}",fullPathWithFileName);
		if(extention.equalsIgnoreCase(".png")||extention.equalsIgnoreCase(".jpg")||extention.equalsIgnoreCase(".jpeg")) {
			
			logger.info("File extention is: {}",extention);
			// file save
			File folder =new File(path);
			if(!folder.exists()) {
				
				// create the folder
				folder.mkdirs();
			}
			// upload
			Files.copy(file.getInputStream(),Paths.get(fullPathWithFileName));
			return fullPathWithFileName;
		}else {
			
						throw new BadAPIRequest("File with this"+extention+"not allowed !!");
		}
		
	
	}

	@Override
	public InputStream getResource(String path, String name) {
		return null;
	}

}

